-- Isadora_Faria_1859869_A2 --


CREATE TABLE bank_loan_table (
  member_id text PRIMARY KEY,
  loan_amnt real,
  funded_amnt real,
  term text,
  interest_rate real,
  grade text,
  sub_grade text,
  emp_length text,
  home_ownership text,
  annual_income real,
  verification_status text,
  issue_date text,
  loan_status text,
  description text,
  purpose text,
  addr_state text,
  total_pymnt real,
  last_pymnt_amnt real,
  application_type text
);

--******************* SECTION 1 (1 MARK) **********************

-- PART 1 (1/2 Mark)

-- Update the table bank_loan_table to add a column called recoveries 

-- You can now import the CSV data like you did in class in Week 6

-- Using the bank_loan_data CSV file (provided by your facilitator) 


ALTER TABLE bank_loan_table 
ADD COLUMN recoveries 


-- Part 2: Simple SELECT Query (1/2 Mark)   
-- Create a SELECT statement that selects the first 10 rows for all columns of data.

-- The fisrt selection was made to visualize all the table, following by the second statement that was created to
-- limit the first 10 rows for all columns of data

SELECT * FROM bank_loan_table blt 


SELECT * FROM bank_loan_table
LIMIT 10;



**************SECTION2***************

-- Part 1: Loan and Funded Amounts
-- Write and execute a query to display the number of customers (count) for the (issue date) year 2015 Grouping by the following purposes:
--	•	Home improvement
--	•	Car
--	•	Medical 


-- This query was used to count how many loans were issued in 2015 for different purposes. "WHERE" was used to filter issued_data and purpose 
-- "COUNT" was included to quantify the amount of loans for each category and "GROUP" was used to aggegate the count for each of the purpose.

SELECT 
    purpose,
    COUNT(*) AS total_customers
FROM bank_loan_table blt 
WHERE 
    purpose IN ('home_improvement', 'car', 'medical')
    AND SUBSTR(issue_date, -4) = '2015'
GROUP BY purpose
ORDER BY total_customers DESC;


-- Part 2: Loan Terms (
-- Write and execute a query that counts the number of the loans based on terms. 
--For example, how many terms (count of loans) are of 36 months for the year 2014 and 2015? 
--How many are of 60 months for issued years of 2014 and 2015?


-- "SUBSTR(issue_date, -4)" was used to filter loans from 2014 and 2015,  COUNT(*) is to measure how many loans were granted
-- in "GROUP BY" issue_year, term the counts are splited for better view and "ORDER BY" was used for earies comparison

SELECT 
    term,
    SUBSTR(issue_date, -4) AS issue_year,
    COUNT(*) AS loan_count
FROM bank_loan_table blt 
WHERE SUBSTR(issue_date, -4) IN ('2014','2015')
GROUP BY issue_year, term
ORDER BY issue_year, term;


-- Part 3: Interest Rates 
-- Write and execute a query to answer the following business questions:
--	What is the average interest rate for year 2015?
--	What is the highest interest rate for the year 2015?
--	What is the lowest interest rate for the year 2015?


-- "SUBSTR(issue_date, -4)" was used to filter the year of 2015 and the query of AVG, MAX and MIN were applied to find 
-- the avarage interest, highest interest and lowest interest rate for the same year.

SELECT 
    SUBSTR(issue_date, -4) AS year,
    ROUND(AVG(intrest_rate),2) AS avg_rate,
    MAX(intrest_rate) AS max_rate,
    MIN(intrest_rate) AS min_rate
FROM bank_loan_table blt 
WHERE SUBSTR(issue_date, -4) = '2015'
GROUP BY year;



-- Part 4: Loan Status 
-- Write and execute a query to answer the following business questions:
-- Counts of the number of loans for each State for year 2013 and 2014

-- The data for 2013 and 2014 were filtered, grouped by addr_state and issue_year to show how many we had for each state in each year. 

SELECT 
    addr_state,
    SUBSTR(issue_date, -4) AS issue_year,
    COUNT(*) AS loan_count
FROM bank_loan_table
WHERE SUBSTR(issue_date, -4) IN ('2013', '2014')
GROUP BY addr_state, issue_year
ORDER BY addr_state, issue_year;


-- For each of the unique States found above, create an SQL statement that displays the first 5 rows of data.


-- In this query " ROW_NUMBER() OVER PARTITION BY TRIM(b.addr_state)" was used for it to show only the first five loans per state for 2013 and 2014

SELECT 
  r.addr_state,
  r.issue_date,
  r.loan_amnt,
  r.term,
  r.grade,
  r.rn
FROM (SELECT
    TRIM(b.addr_state) AS addr_state,
    b.issue_date,
    b.loan_amnt,
    b.term,
    b.grade,
    ROW_NUMBER() OVER (
      PARTITION BY TRIM(b.addr_state)
      ORDER BY b.issue_date
    ) AS rn
  FROM bank_loan_table b
  WHERE SUBSTR(b.issue_date, -4) IN ('2013','2014')
) AS r
WHERE r.rn <= 5
ORDER BY r.addr_state, r.rn;


-- Part 5: Loan Defaults/Delinquencies   - Write your Queries below
-- Write and execute a query to answer the following business questions:
--	Display each loan grade and the count of the number of loans related to it.


-- To make it easy to compare loan distribution in the categories the data was grouped by grade 

SELECT 
    grade,
    COUNT(*) AS total_loans
FROM bank_loan_table blt 
GROUP BY grade
ORDER BY grade;

--	Display each loan sub-grade and the count of the number of loans related to it.

-- To show the number of loans in each sub grade a GROUP by function was used 

SELECT 
    sub_grade,
    COUNT(*) AS total_loans
FROM bank_loan_table blt 
GROUP BY sub_grade
ORDER BY sub_grade;


-- Part 6: Loan Defaults/Delinquencies (2 Marks)

-- Write and execute a query to answer the following business questions:
-- How many customers defaulted on their loan obligations based on the following loan statuses?

-- loan_status was grouped to show how many customer we had in each status, the "ORDER BY" was used to sort from the highest to lowest 

SELECT 
    loan_status,
    COUNT(*) AS total_loans
FROM bank_loan_table blt 
GROUP BY loan_status
ORDER BY total_loans DESC;

-- Charged Off, Default, In Grace Period, Late (16-30 days) and Late (31-120 days)

-- the query helps to identify how many customers are in each of the stages, for that each category was filtered
-- using "WHERE" and grouped on loan_status.

SELECT 
    loan_status, 
    COUNT(*) AS default_count
FROM bank_loan_table
WHERE loan_status IN (
    'Charged Off', 'Default', 'In Grace Period', 
    'Late (16-30 days)', 'Late (31-120 days)'
)
GROUP BY loan_status;